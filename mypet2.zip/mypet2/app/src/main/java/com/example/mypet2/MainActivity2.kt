

package com.example.mypet2

import android.annotation.SuppressLint
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.ProgressBar


class MainActivity2 : AppCompatActivity() {
    @SuppressLint("SuspiciousIndentation")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)
        val bundle:Bundle? = intent.extras




            findViewById<ImageView>(R.id.imageView2)


            findViewById<EditText>(R.id.playtext)
            findViewById<Button>(R.id.playbutton)
            R.drawable.playing






            findViewById<EditText>(R.id.cleanbutton)
            findViewById<Button>(R.id.cleanmebutton)
            R.drawable.bathing




            findViewById<EditText>(R.id.fedbutton)
            findViewById<Button>(R.id.hungrybutton)
            R.drawable.fed















            class MainActivity : AppCompatActivity() {
                private lateinit var happinessBar: ProgressBar

                private var happinessLevel = 50 // Initial happiness level

                @SuppressLint("MissingInflatedId")
                override fun onCreate(savedInstanceState: Bundle?) {
                    super.onCreate(savedInstanceState)
                    setContentView(R.layout.activity_main)

                    happinessBar = findViewById(R.id.hapinessProgressBar)
                    updateProgressBar()

                    // Button click listeners
                    findViewById<Button>(R.id.fedbutton).setOnClickListener {
                        feedPet()
                    }

                    findViewById<Button>(R.id.cleanmebutton).setOnClickListener {
                        cleanPet()
                    }

                    findViewById<Button>(R.id.playbutton).setOnClickListener {
                        playWithPet()
                    }
                }

                private fun feedPet() {
                    // Increase the pet's happiness level by feeding
                    happinessLevel += 10
                    updateProgressBar()
                }

                private fun cleanPet() {
                    // Increase the pet's happiness level by cleaning
                    happinessLevel += 5
                    updateProgressBar()
                }

                private fun playWithPet() {
                    // Increase the pet's happiness level by playing
                    happinessLevel += 15
                    updateProgressBar()
                }

                private fun updateProgressBar() {
                    // Ensure the happiness level stays within the range of the progress bar
                    happinessLevel = happinessLevel.coerceIn(0, 100)

                    // Update the progress bar
                    happinessBar.progress = happinessLevel


                }
            }


        }
    }









